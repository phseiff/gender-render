## Changelog

* spec
  * v0.1.0: Initial release
  * v0.1.1: Diversify branding (RPG dialogues)